import React from 'react';
import "./About.css";
import aboutImg from "../../images/about-img.jpg";

const About = () => {
  return (
    <section className='about'>
      <div className='container'>
        <div className='section-title'>
          <h2>About</h2>
        </div>

        <div className='about-content grid'>
          <div className='about-img'>
            <img src = {aboutImg} alt = "img" width={'100px'} height={'500px'}/>
          </div>
          <div className='about-text'>
            <h2 className='about-title fs-26 ls-1'>About Book-App</h2>
            <p className='fs-19' >Book Management App Created by <b>Nilay, Rishi, Rohan, Rutu</b></p>
            <p className='fs-17'>               Technologies Used :</p>
            <p className='fs-16'>---------------------  FrontEnd  -------------------------</p>
            <p className='fs-15'><b>JSX</b></p>
            <p className='fs-15'><b>CSS</b></p>
            <p className='fs-25'>---------------------  BackEnd  -------------------------</p>
            <p className='fs-15'><b>NodeJS</b></p>
            <p className='fs-15'><b>ExpressJS</b></p>
            <p className='fs-15'><b>bcrypt and JSToken</b></p>
            <p className='fs-15'><b>abc</b></p>

          </div>
        </div>
      </div>
    </section>
  )
}

export default About
