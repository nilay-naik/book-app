const express = require('express');
const router = express.Router();
const fetchuser = require('./auth');
const Note = require('./db/Note');
const { body, validationResult } = require('express-validator');

router.get('/notes', fetchuser, async (req, res) => {
    try {
        console.log('abc2pm');
        // const notes = await Note.find({ user: req.user.id });
        // res.json(notes)
    } catch (error) {
        console.error(error.message);
        res.status(500).send("Internal Server Error");
    }
})


module.exports = router