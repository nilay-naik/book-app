const http = require('http');
const express = require('express')
const appp = express();
const port = 3000
var cors = require('cors') 
appp.use(cors())
appp.use(express.json())

// Available Routes
appp.set('/app', require('./app'))
appp.use('/notes', require('./notes'))


appp.listen(port, () => {
  console.log(`Llistening at http://localhost:${port}`)
})
















// const port =  '3000';
// app.set('port', port);


// const errorHandler = error => {
//   if (error.syscall !== 'listen') {
//     throw error;
//   }
//   const address = server.address();
//   const bind = typeof address === 'string' ? 'pipe ' + address : 'port: ' + port;
//   switch (error.code) {
//     case 'EACCES':
//       console.error(bind + ' requires elevated privileges.');
//       process.exit(1);
//       break;
//     case 'EADDRINUSE':
//       console.error(bind + ' is already in use.');
//       process.exit(1);
//       break;
//     default:
//       throw error;
//   }
// };

// const server = http.createServer(app);

// server.on('error', errorHandler);
// server.on('listening', () => {
//   const address = server.address();
//   const bind = typeof address === 'string' ? 'pipe ' + address : 'port ' + port;
//   console.log('Listening on ' + bind);
// });

// server.listen(port);
