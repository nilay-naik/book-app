const mongoose = require("mongoose");
const NotesSchema = new mongoose.Schema({
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    booktitle : {type: String , 
    required : true}
});

module.exports = mongoose.model('notes', NotesSchema);